# TITU AI Assistant — Android প্রজেক্ট

এটি TITU AI Assistant-এর একটি আধুনিক, মোবাইল-ফ্রেন্ডলি Android WebView অ্যাপ। এতে আছে:
- আধুনিক ডার্ক UI ও নীল-বেগুনি গ্রেডিয়েন্ট
- কাজ করা quick-prompt বাটন ও চ্যাট ইনপুট
- Clear chat বাটন
- সমর্থিত ডিভাইসে উত্তর পড়ে শোনানোর চেষ্টা (Text-to-Speech)
- অফলাইন ডেমো উত্তর; কোনো অ্যাকাউন্ট, API key বা ব্যক্তিগত তথ্য সংগ্রহ নেই

## গুরুত্বপূর্ণ
এটি **অফলাইন ডেমো**, আসল অনলাইন AI সার্ভিস নয়। তাই উত্তরগুলো কিছু নির্দিষ্ট বিষয়ের জন্য পূর্বনির্ধারিত। সত্যিকারের AI API যোগ করতে হলে নিরাপদ backend ও API key ব্যবস্থাপনা দরকার—কখনোই গোপন API key অ্যাপের HTML/ APK-তে রাখবে না।

## APK তৈরি করার সহজ উপায়: GitHub Actions
1. ZIP ফাইলটি Extract করো।
2. GitHub-এ নতুন repository বানাও।
3. এই প্রজেক্টের সব ফাইল repository-তে upload করো (root-এ `settings.gradle`, `build.gradle`, `app/` ও `.github/` থাকবে)।
4. GitHub repository-তে **Actions** tab খোলো।
5. `Build TITU AI Assistant APK` workflow বেছে নিয়ে **Run workflow** চাপো।
6. Build শেষ হলে run-এর পেজে **Artifacts** অংশ থেকে `TITU-AI-Assistant-debug-apk` ডাউনলোড করো।
7. ZIP extract করে `app-debug.apk` Android ফোনে ইনস্টল করো। Android যদি অনুমতি চায়, কেবল পরিচিত নিজের build-এর জন্যই install permission দেবে।

## Android Studio দিয়ে
প্রজেক্টটি Android Studio-তে খোলো, Gradle sync শেষ হতে দাও, তারপর **Build > Build APK(s)** নির্বাচন করো। Debug APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।

## প্রজেক্ট তথ্য
- Package: `com.titu.aiassistant`
- Minimum Android: Android 6.0 (API 23)
- Target/Compile SDK: 35
- App name: TITU AI Assistant
